package variables;

public class MultpleDeclarationAndAssignment {
    public static void main (String[] args){


       // int myFirstInt;
        // int mySecondInt;

        int myFirstInt, mySecondInt;

        double myFirstDouble;
        double mySecondDouble;
        double myThirdDouble;

        double myDouble1, myDouble2, myDouble3;

        //char myFirstChar = 'c';
        //char mySecondChar = 'y';
        //char myThirdChar;
        //char myFourthChar = 'a';

        char myFirstChar = 'c', mySecondChar = 'y', myThirdChar, myFourthChar = 'a';




    }

}
