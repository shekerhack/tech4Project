package variables;

public class MultipleDeclaration {
    public static void main (String[] args){

        int myFirstInt;
        int mySecondInt;

        int myInt1, myInt2, myInt3, myInt4, myInt5;


    }
}
