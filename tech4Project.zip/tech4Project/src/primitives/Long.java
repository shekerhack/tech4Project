package primitives;

public class Long {
    public static void main(String[] args) {
        // containerType label = data
        long shekersNumber = 2L; //2
        long ilkinsNumber=6;

        System.out.println("\'" + shekersNumber + "\'" +  "\n" + "\"" + ilkinsNumber + "\"");

        long maxLong = 9223372036854775807L;
        long minLong = -9223372036854775808L;
        System.out.println(maxLong);
        System.out.println(minLong);

    }
}
