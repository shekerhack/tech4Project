package primitives;

public class Float {
    public static void main(String[] args) {
        // containerType label = data
        float myFirstFloat = 14.5F;
        float mySecondFloat = 45.2F;
        float myThirdFloat = 56.2435556F;

        System.out.print(myFirstFloat);
        System.out.print(mySecondFloat);
        System.out.println(myThirdFloat);

        System.out.println(myFirstFloat + "\n" + mySecondFloat + "\n" + myThirdFloat);
    }

}
