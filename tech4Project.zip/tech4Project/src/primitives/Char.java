package primitives;

public class Char {
    public static void main(String[] args) {
        // containerType label = data
        char initialOfTech = 'T';
        char secondLetterofTech = 'e';

        System.out.println(initialOfTech);
        System.out.println(secondLetterofTech);


    }
}
