package primitives;

public class Double {
    public static void main(String[] args) {
        // containerType label = data

        double myFirstDouble = 123.123456789101216;

        System.out.println(myFirstDouble);

    }
}
