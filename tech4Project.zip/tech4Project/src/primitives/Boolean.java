package primitives;

public class Boolean {
    public static void main(String[] args) {
        // containerType label = data
        boolean myTrueValue = true; //1
        boolean myFalseValue = false; //0

        System.out.println(myTrueValue);
        System.out.println(myFalseValue);
    }
}
