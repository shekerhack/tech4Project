package primitives;

public class Short {
    public static void main(String[] args) {
        // containerType label = data
        short shekersNumber = 54;
        short ilkinsNumber = 16;
        short maxShort = 32676;
        short minShort = -32768;
        System. out.println(shekersNumber);
        System.out.println(ilkinsNumber);
        System.out.println(maxShort);
        System.out.println(minShort);

    }
}
