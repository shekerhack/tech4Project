package primitives;

public class Byte {
    public static void main(String[] args) {
        // containerType label = data Primitive don't start with capital letter
        byte shekersNumber = 12;
        byte ilkinsNumber=23;
        byte maxByte = 127;
        byte minByte = -128;
        System.out.println(shekersNumber); //12
        System.out.println(ilkinsNumber);  //23
        System.out.println(maxByte);
        System.out.println(minByte);
    }
}
