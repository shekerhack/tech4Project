package primitives;

public class Int {
    public static void main(String[] args) {
        //int only for numbers. ContainerType label = data-its numbers
        int shekersnumber=8;
        int ilkinsnumber=7;
                int maxInt = Integer. MAX_VALUE;  //2147483647;
                int minInt = Integer. MIN_VALUE;  // -2147483648
                System.out.println(shekersnumber);   //8
        System.out.println("shekersnumber");  //shekersnumber
        System.out.println(maxInt); //int's max value
        System.out.println(minInt); //int's min value

    }
}