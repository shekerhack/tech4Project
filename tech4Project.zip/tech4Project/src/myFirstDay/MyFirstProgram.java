package myFirstDay;

public class MyFirstProgram {
    public static void main(String[] args) {
        //println, stand for print line. Code in column
        System.out.println("Hello World");
        System.out.println("TechGlobal");
        System.out.println("Today I am sleepy");
        System.out.println("My husband teaches me things ahead and my mind freezes");

        //print, straight line. Code in one row
        System.out.print("TechGlobal");
        System.out.print(" will take 6 month");

        //n-moves the cursor to a new line
        System.out.println("Tech \nGlobal");
        System.out.println("Apple \nOrange");

        //t-tap
        System.out.println("\tTech\nGlobal");
        System.out.println("\tSheker\n\tHakberdiyeva");

        //-\\backward slash
        System.out.println("\"TechGlobal\"\n");
        System.out.println("\'TechGlobal\'\n");
        System.out.println("\\TechGlobal\\");

        System.out.println("\t\"Nikola Tesla\" Serbian Cyrillic pronounced 10 July " +
                "1856 – 7 January 1943 was a Serbian-American\ninventor, electrical engineer, mechanical engineer, " +
                "and futurist best known for his contributions \nto the design of the modern alternating current (AC) electricity supply system");



    }

    }