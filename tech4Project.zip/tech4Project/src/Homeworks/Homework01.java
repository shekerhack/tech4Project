package Homeworks;

import java.util.zip.GZIPInputStream;

public class Homework01 {
    public static void main(String[] args) {
        //G-71, I-73, T-84 Task 1
        System.out.println("01000111");
        System.out.println("01001001");
        System.out.println("01010100");
        //A-65, P-80, P-80, I-73, U-85, M-77
        System.out.println("01000001");
        System.out.println("01010000");
        System.out.println("01001001");
        System.out.println("01010101");
        System.out.println("01001101");

        // Task 2 L-76, h-104, y-121, S-83, l-108
        System.out.println("L");
        System.out.println("h");
        System.out.println("y");
        System.out.println("S");
        System.out.println("l");

        //Task 3
        System.out.println("I start to practice \"JAVA\" today, and I like it.");
        System.out.println("The secret of getting ahead is getting started.");
        System.out.println("\"Don't limit yourself\". ");
        System.out.println("Invest in your dreams. Grind now. Shine later.");
        System.out.println("It’s not the load that breaks you down, it’s the way you carry it.");
        System.out.println("The hard days are what make you stronger.");
        System.out.println("You can waste your lives drawing lines. Or you can live your life crossing them.");

        //Task 4
        System.out.println("\tJava is easy to write and easy to run—this is the foundational strength of Java and why many developers program in it. When you write Java once, you can run it almost anywhere at any time." +
                "\n\tJava can be used to create complete applications that can run on a single computer or be distributed across servers and clients in a network." +
                "\n\tAs a result, you can use it to easily build mobile applications or run-on desktop applications that use different operating systems and servers, such as Linux or Windows.");

        //Task 5

        int myAge=29;
                System.out.println(myAge);

        int myFavoriteNumber=12;
                System.out.println(myFavoriteNumber);

        float myHeight=5.06F;
                System.out.println(myHeight);

         short myWeight=132;
                System.out.println(myWeight);

         char myFavoriteCharacter='∞';
                System.out.println(myFavoriteCharacter);






    }
}
